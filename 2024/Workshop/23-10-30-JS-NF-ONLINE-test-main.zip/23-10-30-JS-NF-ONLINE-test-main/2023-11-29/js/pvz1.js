let vardas14 = 'John', pavarde = 'Deppasasaszz';
    //                          012345
//Sudarysime string tipo kintamąjį iš pirmų dviejų vardo 
//ir paskutinių dviejų pavardės raidžių.
let inicialai = vardas14[0] + vardas14[1] + pavarde[pavarde.length - 2] + pavarde[pavarde.length - 1];

console.log(inicialai);